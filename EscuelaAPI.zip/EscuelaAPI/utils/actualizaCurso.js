const db = require('../models/database/db');
const Op = db.Sequelize.Op;
db.Curso.update({
    creditos: 7
}, {
    where: {
        creditos: {
            [Op.eq]: 6

        }
    }
}).then((res) => {
    console.log('Registros actualizados:', res);
}).catch(err => {
    console.log(err);
}).then(() => {
    console.log('Cerrando conexión');
    db.sequelize.close();
});