const db = require('../models/database/db');
const Op = db.Sequelize.Op;
db.Estudiante.update({
    creditosCursados: 400
}, {
    where: {
        creditosCursados: {
            [Op.eq]: 200

        }
    }
}).then((res) => {
    console.log('Registros actualizados:', res);
}).catch(err => {
    console.log(err);
}).then(() => {
    console.log('Cerrando conexión');
    db.sequelize.close();
});