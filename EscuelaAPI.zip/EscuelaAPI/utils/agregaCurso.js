const db = require('../models/database/db');

db.Curso.create({
    claveCurso: 1,
    nombreCurso: 'Ingenieria de Software',
    creditos: 6
}).then(() => {
    console.log('Curso creado');
}).catch(err => {
    console.log(err);
}).then(() => {
    console.log('Cerrando conexión');
    db.sequelize.close();
});