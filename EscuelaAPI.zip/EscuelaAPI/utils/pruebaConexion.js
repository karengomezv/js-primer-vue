const Sequelize = require('sequelize');

const sequelize = new Sequelize(
    'escuela',
    'root',
    'kgv123.',
    {
        host: 'localhost',
        dialect: 'mysql'
    });

sequelize
.authenticate()
.then(() => {
    console.log('Se conecto exitosamente');
})
.then(()=>{
    cierra();
})
.catch((err)=>{
    console.log('Error al conectarse a la BD: ' , err);
});

const cierra = async function(){
    await sequelize.close();
}
